<?php require APPROOT . '/views/inc/header.php'; ?>

<div class="MA-vistitem2" style="padding: 50px">
    <div style="text-align: center">


        <h1>لا يوجد سجل بالمعلومات المدخلة</h1>
        <div class="ma-tu">
            <a href="<?php echo URLROOT . "/main/qr" ?>"><input class="ma-add" value="رجوع"></a>
        </div>
    </div>


</div>

</body>
</html>
