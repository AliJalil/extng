<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap.min.css"/>
<script type="text/javascript" src="<?php echo URLROOT . "/public/js/DataTables/DataTables-1.10.18/js/jquery.dataTables.min.js"; ?>"></script>
<script type="text/javascript" src="<?php echo URLROOT . "/public/js/DataTables/JSZip-2.5.0/jszip.min.js"; ?>"></script>
<script type="text/javascript"
        src="<?php echo URLROOT . "/public/js/DataTables/Buttons-1.5.4/js/dataTables.buttons.min.js"; ?>"></script>
<script type="text/javascript"
        src="<?php echo URLROOT . "/public/js/DataTables/Buttons-1.5.4/js/buttons.html5.min.js"; ?>"></script>
<script type="text/javascript" src="<?php echo URLROOT . "/public/js/DataTables/Buttons-1.5.4/js/buttons.print.min.js"; ?>"></script>

<link rel="stylesheet" type="text/css" href="<?php echo URLROOT . "/public/js/DataTables/Buttons-1.5.4/css/buttons.dataTables.min.css"; ?>"/>


<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap.min.js"></script>



<script src="<?php echo URLROOT . "/public/vendor/bootstrap4-editable/js/bootstrap-editable.js"; ?>"></script>
<link rel="stylesheet" href="<?php echo URLROOT . "/public/vendor/bootstrap4-editable/css/bootstrap-editable.css"; ?>"/>

<style>

    .dataTables_paginate a {
        padding: 3px 10px !important;
        background:  #E93C3C !important;
        border: 1px solid #c0a16b !important;
        border-radius: 5px;
        margin: 0.5px;
        color: white !important;
    }
</style>
