
<!-- Javascript -->
<link rel="stylesheet" href="<?php echo URLROOT . "/public/css/animalprint.css" ?>" crossorigin="anonymous">
<div class="ma-footer3" style="height: 30px;width: 100%;background: #E93C3C;color: #ffffff; position: fixed;
     bottom: 0px;
     right: 0px;
left: 0px;text-align: center;">
    <a href="https://www.imamali.iq/" style="color: #ffffee!important;font-size: 15px" >
        جميع الحقوق محفوظة للعتبة العلوية المقدسة-مركز تكنلوجيا المعلومات
    </a>

</div>
<script src="<?php echo URLROOT . "/public/assets/plugins/jquery-3.4.1.min.js"; ?>"></script>
<script src="<?php echo URLROOT . "/public/assets/plugins/popper.min.js"; ?>"></script>
<script src="<?php echo URLROOT . "/public/assets/plugins/bootstrap/js/bootstrap.min.js"; ?>"></script>


</body>
</html>

